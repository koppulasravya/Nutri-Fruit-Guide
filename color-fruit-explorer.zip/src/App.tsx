/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, FormEvent } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { 
  Search, Info, Leaf, Activity, Sparkles, Loader2, Apple, 
  Citrus, Cherry, Banana, Grape, Palette, ChevronRight, X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Fruit {
  name: string;
  scientificName: string;
  benefits: string[];
  vitamins: string[];
  colorShade: string;
  emoji: string;
}

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const QUICK_COLORS = [
  { name: 'Red', hex: '#FF4D4D' },
  { name: 'Orange', hex: '#FFA502' },
  { name: 'Yellow', hex: '#ECCC68' },
  { name: 'Green', hex: '#2ED573' },
  { name: 'Purple', hex: '#A55EEA' },
  { name: 'Blue', hex: '#3742FA' }
];

export default function App() {
  const [color, setColor] = useState('');
  const [inputValue, setInputValue] = useState('');
  const [results, setResults] = useState<Fruit[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedFruit, setSelectedFruit] = useState<Fruit | null>(null);

  const fetchFruits = async (searchColor: string) => {
    if (!searchColor.trim()) return;
    
    setIsLoading(true);
    setError(null);
    setSelectedFruit(null);
    
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Find 8-10 interesting fruits that are primarily ${searchColor} in color. 
        For each fruit, provide:
        1. Common name
        2. Scientific name
        3. 3 DISTINCT health benefits
        4. Primary vitamins
        5. A specific hex color code that matches this fruit's shade
        6. The single most accurate emoji for this fruit.
        
        Return as a structured JSON array.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                scientificName: { type: Type.STRING },
                benefits: { 
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                },
                vitamins: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                },
                colorShade: { type: Type.STRING },
                emoji: { type: Type.STRING }
              },
              required: ["name", "scientificName", "benefits", "vitamins", "colorShade", "emoji"]
            }
          }
        }
      });

      const data = JSON.parse(response.text || '[]');
      setResults(data);
      if (data.length === 0) {
        setError(`We couldn't find many fruits for "${searchColor}". Try another color!`);
      }
    } catch (err) {
      console.error(err);
      setError("The orchard is currently unavailable. Please try again in a moment.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      setColor(inputValue);
      fetchFruits(inputValue);
    }
  };

  const handleQuickColor = (colorName: string) => {
    setInputValue(colorName);
    setColor(colorName);
    fetchFruits(colorName);
  };

  return (
    <div className="min-h-screen bg-[#FAFAF8] text-[#2D3436] font-sans selection:bg-[#5A5A40] selection:text-white">
      {/* Background decoration */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-[10%] -left-[10%] w-[40%] h-[40%] bg-[#5A5A40] opacity-[0.02] blur-[120px] rounded-full" />
        <div className="absolute -bottom-[10%] -right-[10%] w-[50%] h-[50%] bg-[#ECCC68] opacity-[0.03] blur-[120px] rounded-full" />
      </div>

      {/* Header */}
      <header className="relative pt-16 pb-12 px-4 text-center max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-sm border border-[#E6E6E6] mb-8"
        >
          <Palette className="w-4 h-4 text-[#5A5A40]" />
          <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#5A5A40]">Nature's Gallery</span>
        </motion.div>
        
        <motion.h1 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-5xl md:text-7xl font-serif font-medium tracking-tight text-[#1A1A1A] mb-6 leading-[1.1]"
        >
          Explore Fruits <br /> 
          <span className="italic font-light text-[#5A5A40]">by their Hue</span>
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-[#636E72] max-w-xl mx-auto text-lg md:text-xl font-serif italic leading-relaxed"
        >
          "Every color in nature tells a story of vitamins, minerals, and life-giving energy. Discover the rainbow."
        </motion.p>
      </header>

      {/* Search & Shortcuts */}
      <section className="relative max-w-3xl mx-auto px-4 mb-16">
        <form onSubmit={handleSearch} className="relative mb-8">
          <div className="relative overflow-hidden rounded-[2rem] shadow-2xl shadow-[#5A5A40]/10">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="What color are you looking for?"
              className="w-full pl-16 pr-40 py-6 bg-white border-none focus:ring-2 focus:ring-[#5A5A40]/10 transition-all outline-none text-2xl placeholder:text-[#B2BEC3] font-serif"
            />
            <Search className="absolute left-7 top-1/2 -translate-y-1/2 w-6 h-6 text-[#5A5A40]" />
            <button 
              type="submit"
              disabled={isLoading}
              className="absolute right-3 top-1/2 -translate-y-1/2 bg-[#1A1A1A] text-white pl-8 pr-10 py-4 rounded-full font-medium hover:bg-[#2D2D2D] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-3 overflow-hidden group"
            >
              <span className="relative z-10">{isLoading ? "Searching..." : "Reveal Fruits"}</span>
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin relative z-10" />
              ) : (
                <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform relative z-10" />
              )}
              <motion.div 
                className="absolute inset-0 bg-[#5A5A40]" 
                initial={{ x: "-100%" }}
                whileHover={{ x: 0 }}
                transition={{ duration: 0.3 }}
              />
            </button>
          </div>
        </form>

        <div className="flex flex-wrap items-center justify-center gap-3">
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#B2BEC3] mr-2">Quick Picks:</span>
          {QUICK_COLORS.map((qc) => (
            <button
              key={qc.name}
              id={`color-btn-${qc.name}`}
              onClick={() => handleQuickColor(qc.name)}
              className="flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-[#E6E6E6] hover:border-[#5A5A40] hover:shadow-md transition-all text-sm font-medium text-[#1A1A1A]"
            >
              <div 
                className="w-3 h-3 rounded-full shadow-inner" 
                style={{ backgroundColor: qc.hex }}
              />
              {qc.name}
            </button>
          ))}
        </div>
      </section>

      {/* Results Section */}
      <main className="max-w-7xl mx-auto px-4 pb-32">
        <AnimatePresence mode="wait">
          {error && (
            <motion.div
              key="error"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="bg-white border-2 border-red-50 p-12 rounded-[32px] text-center max-w-lg mx-auto shadow-xl"
            >
              <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
                <Info className="w-8 h-8 text-red-400" />
              </div>
              <h2 className="text-2xl font-serif font-bold text-[#1A1A1A] mb-2">The Orchard is Still</h2>
              <p className="text-[#636E72] italic mb-8">{error}</p>
              <button 
                onClick={() => setInputValue('')}
                className="text-[#5A5A40] font-bold text-sm uppercase tracking-widest hover:underline"
              >
                Clear Search
              </button>
            </motion.div>
          )}

          {isLoading ? (
            <motion.div
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                <div key={i} className="bg-white rounded-[32px] p-8 border border-[#E6E6E6] h-[500px] animate-pulse">
                  <div className="w-20 h-20 bg-[#F5F5F0] rounded-[24px] mb-8" />
                  <div className="h-10 bg-[#F5F5F0] rounded-lg w-3/4 mb-4" />
                  <div className="h-4 bg-[#F5F5F0] rounded w-1/2 mb-10" />
                  <div className="space-y-4">
                    <div className="h-6 bg-[#F5F5F0] rounded w-full" />
                    <div className="h-6 bg-[#F5F5F0] rounded w-full" />
                    <div className="h-6 bg-[#F5F5F0] rounded w-full" />
                  </div>
                </div>
              ))}
            </motion.div>
          ) : results.length > 0 ? (
            <motion.div
              key="results"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8"
            >
              {results.map((fruit, idx) => {
                return (
                  <motion.article
                    key={`${fruit.name}-${idx}`}
                    id={`fruit-card-${idx}`}
                    initial={{ opacity: 0, scale: 0.9, y: 30 }}
                    whileInView={{ opacity: 1, scale: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: (idx % 4) * 0.1 }}
                    className="bg-white rounded-[32px] p-8 border border-[#E6E6E6] shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all group flex flex-col h-full relative overflow-hidden"
                  >
                    {/* Background glow shadow */}
                    <div 
                      className="absolute -top-20 -right-20 w-40 h-40 opacity-[0.05] group-hover:opacity-[0.1] transition-opacity blur-[40px] rounded-full"
                      style={{ backgroundColor: fruit.colorShade }}
                    />
                    
                    <div className="flex items-start justify-between mb-8 relative z-10">
                      <button 
                        onClick={() => setSelectedFruit(fruit)}
                        className="w-20 h-20 rounded-[24px] flex items-center justify-center shadow-sm relative overflow-hidden group-hover:scale-110 transition-transform duration-500 cursor-pointer active:scale-95"
                        style={{ backgroundColor: `${fruit.colorShade}15` }}
                      >
                        <span className="text-4xl transition-transform duration-500 group-hover:rotate-12">{fruit.emoji}</span>
                        <div className="absolute inset-0 bg-black/0 hover:bg-black/5 transition-colors flex items-center justify-center">
                          <motion.div 
                            animate={{ opacity: [0, 1, 0] }}
                            transition={{ repeat: Infinity, duration: 2 }}
                            className="bg-white/20 p-2 rounded-full hidden group-hover:block"
                          >
                            <Sparkles className="w-4 h-4 text-white" />
                          </motion.div>
                        </div>
                      </button>
                      <div 
                        className="px-3 py-1 rounded-full text-[9px] font-bold uppercase tracking-widest border"
                        style={{ borderColor: `${fruit.colorShade}40`, color: fruit.colorShade, backgroundColor: `${fruit.colorShade}05` }}
                      >
                        {fruit.colorShade}
                      </div>
                    </div>

                    <div className="relative z-10 flex-grow">
                      <h2 className="text-3xl font-serif font-medium text-[#1A1A1A] mb-2 leading-tight">
                        {fruit.name}
                      </h2>
                      <p className="text-[#636E72] italic font-serif text-sm mb-8 opacity-60">
                        {fruit.scientificName}
                      </p>

                      <div className="space-y-4">
                        <div>
                          <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#B2BEC3] mb-3 flex items-center gap-2">
                            <Sparkles className="w-3 h-3" /> Essential Vitamins
                          </h3>
                          <div className="flex flex-wrap gap-2">
                            {fruit.vitamins.map((vitamin) => (
                              <span 
                                key={vitamin}
                                className="text-[10px] font-bold bg-[#F9F9F7] text-[#1A1A1A] px-3 py-1.5 rounded-lg border border-[#E6E6E6] group-hover:bg-white transition-colors"
                              >
                                {vitamin}
                              </span>
                            ))}
                          </div>
                        </div>

                        <p className="text-xs text-[#636E72] italic leading-relaxed line-clamp-2">
                          Click the emoji to see botanical benefits grow...
                        </p>
                      </div>
                    </div>
                  </motion.article>
                );
              })}
            </motion.div>
          ) : !isLoading && color && (
             <motion.div 
               initial={{ opacity: 0, y: 20 }}
               animate={{ opacity: 1, y: 0 }}
               className="text-center py-32 bg-white border-2 border-dashed border-[#E6E6E6] rounded-[48px] max-w-4xl mx-auto"
             >
               <Leaf className="w-20 h-20 mx-auto text-[#B2BEC3] mb-8 opacity-20" />
               <h3 className="text-3xl font-serif text-[#1A1A1A] mb-4">Nature is waiting for you</h3>
               <p className="text-[#636E72] font-serif italic text-xl max-w-md mx-auto">Select a color or type one in to reveal the fruits hidden in nature's palette.</p>
             </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Benefits Tree Modal */}
      <AnimatePresence>
        {selectedFruit && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedFruit(null)}
              className="absolute inset-0 bg-[#1A1A1A]/80 backdrop-blur-xl"
            />
            
            <motion.div 
              className="relative w-full max-w-4xl aspect-[4/3] md:aspect-square bg-[#FDFDFB] rounded-[48px] shadow-2xl overflow-hidden flex items-center justify-center"
              initial={{ opacity: 0, scale: 0.9, y: 50 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 50 }}
            >
              <button 
                onClick={() => setSelectedFruit(null)}
                className="absolute top-8 right-8 p-3 bg-[#F5F5F0] rounded-full hover:bg-[#E6E6E6] transition-colors z-30"
                id="close-tree-btn"
              >
                <X className="w-6 h-6 text-[#1A1A1A]" />
              </button>

              <div className="relative w-full h-full flex flex-col items-center justify-center p-12">
                {/* The Tree Center */}
                <div className="relative z-20 text-center mb-16">
                  <motion.div 
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ type: "spring", damping: 12 }}
                    className="w-32 h-32 rounded-[40px] flex items-center justify-center shadow-lg relative mb-6 mx-auto bg-white border-4 border-[#F5F5F0]"
                  >
                    <span className="text-6xl">{selectedFruit.emoji}</span>
                  </motion.div>
                  <motion.h2 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-5xl font-serif font-bold text-[#1A1A1A] mb-2"
                  >
                    {selectedFruit.name}
                  </motion.h2>
                  <motion.p 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-xl font-serif italic text-[#636E72]"
                  >
                    {selectedFruit.scientificName}
                  </motion.p>
                </div>

                {/* Branches */}
                <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                  {selectedFruit.benefits.map((benefit, i) => {
                    // Position branches around the center
                    const total = selectedFruit.benefits.length;
                    const angle = (360 / total) * i - 90;
                    const distance = 240;
                    const rad = (angle * Math.PI) / 180;
                    const x = Math.cos(rad) * distance;
                    const y = Math.sin(rad) * distance;

                    return (
                      <div key={i} className="absolute flex flex-col items-center justify-center">
                        {/* Branch Line */}
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: distance }}
                          transition={{ delay: 0.5 + i * 0.2, duration: 1, ease: [0.16, 1, 0.3, 1] }}
                          className="absolute h-[2px] origin-left bg-gradient-to-r from-[#E6E6E6] to-[#B2BEC3]"
                          style={{ transform: `rotate(${angle}deg)` }}
                        />
                        
                        {/* Benefit Node */}
                        <motion.div 
                          initial={{ opacity: 0, scale: 0, x: 0, y: 0 }}
                          animate={{ opacity: 1, scale: 1, x, y }}
                          transition={{ delay: 1 + i * 0.2, type: "spring", damping: 10 }}
                          className="absolute bg-white border border-[#E6E6E6] p-5 rounded-[24px] shadow-xl w-60 text-center pointer-events-auto hover:border-[#1A1A1A] transition-all group"
                        >
                          <div 
                            className="w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-3"
                            style={{ backgroundColor: `${selectedFruit.colorShade}15` }}
                          >
                            <Activity className="w-5 h-5 transition-transform group-hover:scale-110" style={{ color: selectedFruit.colorShade }} />
                          </div>
                          <p className="text-xs font-medium leading-relaxed italic text-[#2D3436]">{benefit}</p>
                        </motion.div>
                      </div>
                    );
                  })}
                </div>

                {/* Ambient Particles */}
                <div className="absolute inset-0 overflow-hidden pointer-events-none">
                  {[...Array(15)].map((_, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, scale: 0 }}
                      animate={{ 
                        opacity: [0, 0.3, 0], 
                        scale: [0, 1, 0],
                        x: (Math.random() - 0.5) * 800,
                        y: (Math.random() - 0.5) * 800
                      }}
                      transition={{ 
                        repeat: Infinity, 
                        duration: 4 + Math.random() * 2,
                        delay: Math.random() * 2
                      }}
                      className="absolute w-2 h-2 rounded-full blur-[1px]"
                      style={{ backgroundColor: selectedFruit.colorShade }}
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="relative bg-white border-t border-[#E6E6E6] pt-24 pb-16 px-4 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[80%] h-[1px] bg-gradient-to-r from-transparent via-[#5A5A40]/10 to-transparent" />
        <div className="max-w-7xl mx-auto flex flex-col items-center">
          <div className="flex items-center gap-6 mb-12">
             {[Apple, Citrus, Cherry, Banana, Grape].map((Icon, i) => (
               <Icon key={i} className="w-5 h-5 text-[#B2BEC3] opacity-30" />
             ))}
          </div>
          <p className="text-[11px] font-bold uppercase tracking-[0.3em] text-[#B2BEC3] transition-colors hover:text-[#5A5A40] cursor-default text-center">
            Ethically sourced botanical data • Powered by Gemini AI
          </p>
          <p className="mt-4 text-[#B2BEC3] font-serif italic text-sm">
            © 2026 Color Fruit Explorer
          </p>
        </div>
      </footer>
    </div>
  );
}

